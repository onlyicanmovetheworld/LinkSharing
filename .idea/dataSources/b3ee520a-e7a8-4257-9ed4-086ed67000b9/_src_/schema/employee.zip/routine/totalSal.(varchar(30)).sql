CREATE FUNCTION totalSal(dept_name VARCHAR(30))
  RETURNS INT
  begin
declare totalSal int ;
select sum(emp_salary) into totalSal from employee_info
where emp_dept = dept_name;
return totalSal;
end;
